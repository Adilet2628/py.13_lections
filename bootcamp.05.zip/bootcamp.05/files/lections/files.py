# Работа с файлами

# Каретка - Указатель - Курсор

# open(<путь до файла>)

# file = open('files.py') # Относительный путь
# ~ working -> Desktop/bootcamp.05/files/lections/files.py
# files -> lections/files.py

# base_dir = '/Users/sanzhar/Desktop/bootcamp.05/files/'
# file = open(base_dir + 'lections/files.py')

# file = open('files.py')
# data = file.read()
# print(data, type(data))
# file.close()


# Режимы работы с файлами
# 1. r/r+/rb -> read - для чтения файлов
# 2. w/w+/wb -> write - для записи данных
# 3. a/a+ -> для добавления данных
# b, x 


# file = open('test.txt', 'r')
# print(file.read())
# file.close()


# file = open('test.txt', 'r')
# print(file.readlines())
# file.close()

# file = open('test.txt', 'r')
# print(file.readline())
# print(file.readline())
# print("!!!!!")
# print(file.read())
# file.close()

# file.tell() - Возвращает индекс где находится курсор(указатель)
# file.seek() - Перемещает курсор на индекс который вы передали 


# file = open('test.txt', 'r')
# print(file.tell()) # 0
# data = file.read()
# print(data, '!!')
# print(file.tell()) # 275
# file.seek(0)
# print(file.tell()) # 0
# print(file.read())
# print(file.tell()) # 275
# file.close()


# контекстный менеджер
# with open('test.txt', 'r') as file: # file = open()
#     data = file.read()
#     print(data)
#     print(file, 'inside')

# print(file.read(), 'outside')

# with open('test.txt', 'w') as file:
#     file.write('Pervaya stroka!\n')
#     file.write('He is bastard of Ned Stark!\n')
#     file.write('This is lection about files!\n')
#     # file.seek(0)
#     data = ['Test 1 stroka!\n', 'Test 2 stroka!']
#     file.writelines(data)

# with open('test.txt', 'a+') as f:
#     f.seek(0)
#     f.write('\nJohn Snow is King of North!')
#     f.write('\nYou know nothing John Snow!')
#     f.seek(0)
#     print(f.read())

# -------------------

# from PIL import Image
# import pytesseract
# import re

# base_url = '/Users/sanzhar/Desktop/bootcamp.05/files/lections/' 

# def get_imei_code(image: str):
#     string = pytesseract.image_to_string(image)
#     # print(string)
#     list_of_imei = re.findall(r'IMEI\d.\s\d+', string)
#     print(list_of_imei)

#     with open('imei_codes.txt', 'w') as file:
#         file.writelines(f'{x}\n' for x in list_of_imei)
#         # for x in list_of_imei:
#             # file.write(f'{x}\n')

# image = base_url + 'imei.jpg'
# get_imei_code(image)



# 1) Напишите функцию read_last(lines, file), которая будет открывать определенный файл file и выводить на печать построчно последние строки в количестве lines (на всякий случай проверим, что задано положительное целое число). Протестируем функцию на файле «article.txt» со следующим содержимым: Вечерело Жужжали мухи Светил фонарик Кипела вода в чайнике Венера зажглась на небе Деревья шумели Тучи разошлись Листва зеленела


# 2) Выберите любую папку на своем компьютере, имеющую вложенные директории. Выведите на печать в терминал ее содержимое, как и всех подкаталогов при помощи функции print_docs(directory).
# Проход по все каталогам и файлам в определенной директории можно осуществить при помощи функции walk() модуля os.


# 3) Документ «article.txt» содержит следующий текст: Вечерело Жужжали мухи Светил фонарик Кипела вода в чайнике Венера зажглась на небе Деревья шумели Тучи разошлись Листва зеленела Требуется реализовать функцию longest_words(file), которая выводит слово, имеющее максимальную длину (или список слов, если таковых несколько).


# 4) Требуется создать csv-файл «rows_300.csv» со следующими столбцами: – № - номер по порядку (от 1 до 300); – Секунда – текущая секунда на вашем ПК; – Микросекунда – текущая миллисекунда на часах. На каждой итерации цикла искусственно приостанавливайте скрипт на 0,01 секунды.


# 5) При помощи библиотеки Pillow в директории circles (создайте ее во время выполнения функции) нарисуйте и сохраните 100 кругов радиусом 300 пикселей случайных цветов в формате jpg на белом фоне (каждый круг - отдельный файл). Для этого напишите функцию circles_generator(num_of_circles=100).
# В первую очередь требуется установка модуля Pillow: pip install Pillow 
# Осталось только случайным образом генерировать цвета в палитре RGB и воспользоваться классами Image, ImageDraw из установленной библиотеки. Чтобы нарисовать круг, нужно применить метод ellipse() и задать координаты точек, соответствующие квадрату.


# 6) Имеется текстовый файл prices.txt с информацией о заказе из интернет магазина. В нем каждая строка с помощью символа табуляции \t разделена на три колонки:
# наименование товара;
# количество товара (целое число);
# цена (в рублях) товара за 1 шт. (целое число).
# Напишите программу, подсчитывающую общую стоимость заказа.

# 7) Словарь из csv. Имеется файл data.csv, содержащий информацию в csv-формате. Напишите функцию read_csv() для чтения данных из этого файла. Она должна возвращать список словарей, интерпретируя первую строку как имена ключей, а каждую последующую строку как значения этих ключей. Функция read_csv() не должна принимать аргументов.


# 8) Запрещенные слова
# Напишите программу, которая получает на вход строку с названием текстового файла, и выводит на экран содержимое этого файла, заменяя все запрещенные слова звездочками * (количество звездочек равно количеству букв в слове). Запрещенные слова, разделенные символом пробела, хранятся в текстовом файле forbidden_words.txt. Все слова в этом файле записаны в нижнем регистре. Программа должна заменить запрещенные слова, где бы они ни встречались, даже в середине другого слова. Замена производится независимо от регистра: если файл forbidden_words.txt содержит запрещенное слово exam, то слова exam, Exam, ExaM, EXAM и exAm должны быть заменены на ****.
# Формат ввода
# Строка текста с именем существующего текстового файла, в котором необходимо заменить запрещенные слова звездочками.
# Формат вывода
# Текст, отредактированный в соответствии с условием задачи.
# Пример ввода вывода
# Предположим, что forbidden_words.txt содержит следующие запрещенные слова:
# hello email python the exam wor is
# А текст файла, подлежащего цензуре, выглядит так:
# Hello, world! Python IS the programming language of thE future. My EMAIL is.... PYTHON is awesome!!!!
# Тогда программа должна вывести отредактированный текст в таком виде:
# *, *ld! **  * programming language of * future. My * .... **  awesome!!!!


# 9) В текстовый файл построчно записаны фамилия и имя учащихся класса и его оценка за контрольную. Вывести на экран всех учащихся, чья оценка меньше 3 баллов

# 10) Выведите в обратном порядке содержимое всего файла полностью. Для этого считайте файл целиком при помощи метода read().
# Примеры
# входные данные:
# Beautiful is better than ugly. 
# Explicit is better than implicit. 
# Simple is better than complex.
# Complex is better than complicated.

# выходные данные:
# .detacilpmoc naht retteb si xelpmoC 
# .xelpmoc naht retteb si elpmiS 
# .ticilpmi naht retteb si ticilpxE 
# .ylgu naht retteb si lufituaeB









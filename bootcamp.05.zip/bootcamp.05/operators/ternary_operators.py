# num = int(input('Vvedite chislo: '))

# if num % 2 == 0:
#     print('even!')
# else:
#     print('odd!')

# res = 'even' if num % 2 == 0 else 'odd'
# print(res)
# print('even' if num % 2 == 0 else 'odd')

# ---------------------------------
# Ternary operators(тернарный оператор) - это конструкция  которая по своему действию аналогична конструкции if/else, но при этом записывается в одну строчку
# <выражение если True> if <условие> else <выражение если False>

# sentence = input('Vvedite predlojeniye: ')

# if sentence[-1] == '?':
#     res = 'Voprositel\'noe!'
# else:
#     res = 'Normal one!'

# res1 = 'Voprositel\'noe!' if sentence[-1] == '?' else  'Normal one!'

# print(res, res1)


# ls = [55, 12, 75, 89, 99, 15, 11]
# print(ls)

# choice = input('Vvedite min/max: ').lower().strip()
# res = max(ls) if choice == 'max' else min(ls) if choice == 'min' else 'incorrect choice!'

# print(res)

# ---------------------------

flag = True
symbols = '0123456789' + '-' + '.'

while flag:
    print()
    num1 = input('Введите первое число: ')
    is_correct = True
    for x in num1:
        if x not in symbols:
            print('Вы ввели неправильное число!')
            is_correct = False
            break
    if not is_correct:
        continue
    
    num2 = input('Введите второе число: ')
    is_correct = True
    for x in num2:
        if x not in symbols:
            print('Вы ввели неправильное число!')
            is_correct = False
            break
    if not is_correct:
        continue

    num1 = float(num1) if '.' in num1 else int(num1)
    num2 = float(num2) if '.' in num2 else int(num2)
    # print(num1, type(num1))
    # print(num2, type(num2))
    operator = input('Введите операцию(+,-,*,/): ').strip()
    if operator == '+': 
        print(f'Результат: {num1 + num2}')
    elif operator == '-':
        print(f'Результат: {num1 - num2}')
    elif operator == '*':
        print(f'Результат: {num1 * num2}')
    elif operator == '/':
        print(f'Результат: {num1 / num2}' if num2 != 0 else 'На ноль делить нельзя!')
    else:
        print('Вы ввели неверный оператор!')
    
    choice = input('Хотите продолжить?(уes/no): ')
    if choice.lower().strip() != 'yes':
        flag = False
        print('Пока пока!')

    







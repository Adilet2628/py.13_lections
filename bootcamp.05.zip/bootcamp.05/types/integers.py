# Типы данных - Числа ->  int, float

# = -> оператор присваивания
# variable(переменная)
# num = 5
# print(num) # 5
# num = 79 # переопределенние
# print(num) # 79

# abc - нижний регистр 
# ABC - верхний регистр

# PEP8 - правила написания кода на питоне 
# tomorrow_day = '27.09.2023' # Snake case
# tomorrowDay = '27.09.2023' # Camel case

# +
# num1 = 54
# num2 = 67
# print('Result', num1, '+', num2, '=', num1 + num2)
    # Result 5 + 15 = 20

# -
# print(55 - 54)
# print(45 - 5.5)

# *
# num1 = input('Enter the num1: ') # -> int('5') -> 5 
# num2 = input('Enter the num2: ')

# num1 = int(num1)
# num2 = int(num2)

# result = num1 * num2
# print(num1, '*', num2, '=', result)

# / and // and %
# / - обычное деление
# // - деление без остатка
# % - модульное деление(получение остатка от деление) 

# num1 = 7
# num2 = 3
# print('/', num1 / num2) # 2.3333333..
# print('//', num1 // num2) # 2
# print('%', num1 % num2) # 1

# **
# print(5 ** 2) # 5 * 5
# print(5 ** 3) # 5 * 5 * 5

# print(9 ** 0.5) # 3 # квадратный корень

# pow - возведение в степень
# pow(num1, num2, <mod>)
# print(pow(5, 3, 10))
# print(5 ** 3 % 10)

# round() - округление числа с плавающей точкой
# num1 = 5.367
# print(round(num1, 2))

# abs() - абсолютное значение ->  |-67| -> 67
# a = abs(-16)
# b = abs(16)
# print(a, b)

# divmod(a, b) -> Она выводит два числа, первое число это a // b, а второе число a % b

# print(divmod(5, 2)) # 2, 1
# print(5 // 2, 5 % 2) # 2, 1

# множественное присваивание 
# = это оператор присваивания 

# num1, num2, num3 = 4, 10 ,7
# print(num1, num2, num3)

# num1, num2 = divmod(27, 8)
# print(num1, num2)

# import math

# # res = math.sqrt(144)
# # print(res) # 12

# res = math.factorial(235) # 2 * 3 * 4 * 5
# print(res) 

"""Дана переменная с радиусом окружности, найдите периметр и площадь окружности, результат выведите в терминал"""

import math 

r = int(input('Vvedite radius: '))
chislo_pi = math.pi

res_P = 2 * r * chislo_pi
res_S = chislo_pi * (r ** 2)
print('S okrujnosti: ', round(res_S, 2))
print('P okrujnosti: ', round(res_P, 2))



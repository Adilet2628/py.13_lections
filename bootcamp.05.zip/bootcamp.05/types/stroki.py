# 'String - Строки'
# "Hello world! My name is John Snow!"


# str1 = """
# I'm John Snow.
# I'm King of North!
# """
# print(str1)

# Строки - набор последовательных символов, которые мы используем для хранения и представления текстовой информации

# Индексация в строке
# name = 'John'
#         # J = 0 = -4
#         # o = 1 = -3
#         # h = 2 = -2
#         # n = 3 = -1
# print(name)
# print(name[-1])
# str1 = 'world'
# print(str1[0], str1[3])

# срезы по индексам
# [start: end: <step>]
# str1 = 'birthday'
# print(str1)
# print(str1[0:5])
# print(str1[5:])
# print(str1[:5])
# print(str1[:16])

# text = 'Hello world! My name is John Snow! I\'m King of North!'
# print(text[::2])
# print(text[::-1])

# Конкатенация строк(соединение) +
# a = 'Hello'
# b = 'World'
# c = ' '
# res = a + c + b
# print(res)

# *
# a = 'abc'
# print(a * 5)

# экранирование
# \n -> перенос строки
# \t -> горизонтальная табуляция
# str1 = 'Hello World!\n\tHello John!'
# print(str1)

# Форматирование строк
# 1. c помощью %
# 2. с использованием .format()
# 3. интерполяция (пребразование строк) f-строки

# %
# name = input('Vvedite imya: ')
# last_name = input('Vvedite familiyu: ')
# str1 = 'Hello mr/mrs %s %s!' %(name, last_name)
# print(str1)

# .format
# name = input('Vvedite imya: ')
# last_name = input('Vvedite familiyu: ')
# club = 'Kipish'
# print('Welcome to the club {}, mr/mrs {} {}!'.format(club, name, last_name))

# f-строки
# name = input('Vvedite imya: ')
# last_name = input('Vvedite familiyu: ')
# print(f'Hello mr/mrs {name} {last_name}! Welcome to the party!')

#  --------------------------------------
# методы строк - dir()

# print(dir(str))
# replace(old, new, [count]) - меняет в строке old на new, заменит count раз если передадите

# text = 'ha ha ha ha'
# res = text.replace('a', 'e', 3)
# print(text)
# print(f'result after replace: {res}')

# strip() - убирает пробельные символы в начале и в конце строки 
# rstrip, lstrip
# a = '    Hello     '
# print(a, len(a))
# res = a.strip()
# print(res, len(res))

# isdigit   -           Проверяют
# isnumeric - ->  состоит ли наша строка 
# isdecimal -      полностью из чисел

# a = '56'
# print(a.isdigit())

# num = input('Vvedite chislo: ')
# print(f'Vvedeno li chislo?: {num.isdigit()}')

# isalpha - состоит ли наша строка из символов алфавита
# txt = 'Hello world'
# print(txt)
# print(txt.isalpha())
# res = txt.replace(' ', '')
# print(res)
# print(res.isalpha())

# index(value, [start], [end]) - выводит индекс значения value внутри строки
# find(value, [start], [end]) - делает тоже самое что и index, но если не нашел то вернется -1

# text = 'Hello john snow'
# print(text.find('j', 8))
# print(text.index('a'))

# count(value, [start]) - считает количество символов value внутри строки 

# text = 'hello oooo oo o hello'
# print(text.count('a'))
# print(text.count('o'))
# print(text.count('hello'))
# print(text.count('hills'))

# split(separator) - дробит(разделяет) строку на несколько частей по разделителю, все части сохранятся в типе list

# text = 'Let me speak by my heart!'
# res = text.split('e')
# print(text)
# print(res)
# print(text.split())

# a = '#hello#life#love#bishkek'
# print(a)
# print(a[1:].split('#'))

# 'connector'.join(list) - соединяет по connector строки которые были в list 

# a = '#hello#life#love#bishkek#hiking'
# ls = a[1:].split('#')
# print(a)
# print(ls) # ['hello', 'life', 'love', 'bishkek', 'hiking']
# res = '-'.join(ls)
# print(res)

# swapcase() - переводит все символы в противоположный регистр
# upper() - переводит все в верхний регистр
# lower() - переводит все в нижний регистр

# text = 'Hello WorLD, JOHN snow'
# print(f'Original: {text}')
# print(text.upper())
# print(text.lower())
# print(text.swapcase())

# capitalize() - переводит самый первый символ в верхний регистр
# title() - переводит первые символы всех слов в верхний регистр

# john.capitalize() -> John
# name = input('Vvedite imya: ').capitalize()
# print(name)
# print(f'Hello! Mr/Mrs {name}!')

# fio = 'jOHN edart snow'
# print(fio.title())
# print(fio.capitalize())

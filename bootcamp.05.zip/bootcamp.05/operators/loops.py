# while <expression>:
#     <body>

# i = 0
# while 'string':
#     print(f'Srabotalo: {i} raz!')
#     i += 1 # i = i + 1  increment

# i = 0
# while i < 10:
#     i += 1
#     print(f'Цикл сработал {i} раз!')

# ls = list(range(1, 51))
# ls.reverse()
# print(ls)

# while ls:
#     print(ls.pop())


# user = {'username': 'JohnSnow', 'password': 'ilovepython123'}
# print(user)

# i = 3
# password = None
# while password != user['password']:
#     password = input(f'{user["username"]} vvedite paraol\': ')
#     i -= 1
#     if i == 0:  
#         print('Vy Zablokirovany!')
#         break
# else:
#     print(f'Vy uspeshno zashli na sait {user["username"]}')

# ------------------------------

# user = {'username': 'JohnSnow', 'password': 'ilovepython123'}
# print(user)

# i = 3
# while password := input(f'{user["username"]} vvedite paraol\': ') != user['password']:
#     i -= 1
#     if i == 0 :  
#         print('Vy Zablokirovany!')
#         break
# else:
#     print(f'Vy uspeshno zashli na sait {user["username"]}')

# i = 0
# while i < 15:
#     i += 1
#     print(i)

# ------------------------------------------

# for <variable> in <iterable object>:
#     <body>

# range(1, 5) -> 1,2,3,4,5
# 'string' -> s t r i n g
# [1, None, 15, False] -> 1 None 15 False
# 15 -> -----
# True -> -----

# i = iter('string')
# print(i)
# print(next(i)) # 's'
# print(next(i)) # 't'
# print(next(i)) # 'r'
# print(next(i)) # 'i'
# print(next(i)) # 'n'
# print(next(i)) # 'g'

# str1 = 'string'
# for x in str1:
#     if x == 'r':
#         continue
#     print(x)
# else:
#     print('The END!')

# ls = ['Tirion', 'John', 'Sansa', 'Jamie', 'Eddart']
# for x in ls:
#     if x == 'Sansa':
#         continue
#     print(f'Hello Mr/Mrs {x}!')

# число 100 
# Надо найти все делители числа 
    
# 9 -> 1, 3, 9
# 100 -> 
# 1,   2,  4,  5 , 10
# 100, 50, 25, 20, 10 
# 144 ->
# 1,  2,   3,   4,  6,  8,  9, 12
# 144, 72, 48, 36, 24, 18, 16, 12

# num = 100_380_450_000_232
# num = 144
# root = int(num ** 0.5)
# res = []

# for x in range(1, root + 1):
#     print(x)
#     if num % x == 0:
#         res.extend({x, num // x})
# res.sort()
# print(res)

# --------------------------

# import random

# ls = ['Plov', 'Manty', 'Kuurdak', 'Lagman', 'Besh-Barmak']
# p = m = k = l = b = 0

# for x in range(1_000_000):
#     meal = random.choice(ls)
#     if meal == 'Plov': p += 1
#     elif meal == 'Manty': m += 1
#     elif meal == 'Kuurdak': k += 1
#     elif meal == 'Lagman': l += 1
#     else: b += 1

# print('Результат голодных игр:')
# dict_ = {'Plov': p, 'Besh-barkmak': b, 'Kuurdak': k, 'Manty': m, 'Lagman': l}
# print(dict_)

i = 1
ls = [1,2,3,4,5,6,7,8,10]
stop = False
while i < 10:
    if stop:
        break
    for x in ls:
        print(x, '1111')
        if x == 5 and i == 5:
            stop = True
    print(i, '!!!!!!!!!!!!!!!!')
    i += 1

    













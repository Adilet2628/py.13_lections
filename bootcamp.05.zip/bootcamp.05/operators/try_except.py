# обработка исключений 
# операторы try...except


# Ошибки Errors -> связаны с кодом
    # SyntaxError
    # TabError
    # IndentationError

# print('Hello')
# a = 5
# print(a)
# b = 6
# print(b)
# var = int('56')

# Исключения Exceptions -> связаны с неправильным вводом данных которые передаются в код
# ValueError
# TypeError
# NameError
# ZeroDivisionError
# IndexError
# KeyError
# ImportError
# BaseException # прородитель всех ошибок
# print(dir(__builtins__))

# try:
#     num1 = int(input('Enter the num1: '))
#     num2 = int(input('Enter the num2: '))
#     print(num1 / num2)
# except ValueError:
#     print('Invalid values for num!')
# except ZeroDivisionError:
#     print('Cant divide by zero!')


# try:
    # <body> # код с вероятным исключением
# except:
    # <body except> сработает только если ошибка в try
# <else>:
    # <body> сработает только если нет ошибки в try
# <finally>:
    # <body> сработает в любом случае

# dict_ = {1: 'one', 2: 'two', 3: 'three'}
# print(dict_)
# try:
#     key = int(input('Vvedite key: ')) 
#     print(dict_[key])
# except ValueError:
#     print('Invalid value for key!')
# except KeyError:
#     print('Key does not exists!')
# else:
#     print('No errors!')
# finally:
#     print('The end!')

# -----------------------
# отображение ошибки
# 1. import sys

# ls = [1,2,3,4,5]
# try:
#     index = int(input('Vvedite index: '))
#     print(ls[index])
# except:
#     import sys
#     print(f'oops, we catched {sys.exc_info()[0]} error!')

# 2. Exception as e 
# ls = [1,2,3,4,5]
# while True:
#     try:
#         index = int(input('Vvedite index: '))
#         print(ls[index])
#     except Exception as e:
#         print(f'Oops, we catched {e.__class__} error!')

# --------------------------------------------

# flag = True
# symbols = '0123456789' + '-' + '.'

# while flag:
#     print()
#     num1 = input('Введите первое число: ')
#     num2 = input('Введите второе число: ')
#     try:
#         num1 = float(num1) if '.' in num1 else int(num1)
#         num2 = float(num2) if '.' in num2 else int(num2)
#     except ValueError:
#         print('Вы ввели некорректное число!')
#         continue

#     operator = input('Введите операцию(+,-,*,/): ').strip()
#     if operator == '+': 
#         print(f'Результат: {num1 + num2}')
#     elif operator == '-':
#         print(f'Результат: {num1 - num2}')
#     elif operator == '*':
#         print(f'Результат: {num1 * num2}')
#     elif operator == '/':
#         print(f'Результат: {num1 / num2}' if num2 != 0 else 'На ноль делить нельзя!')
#     else:
#         print('Вы ввели неверный оператор!')
    
#     choice = input('Хотите продолжить?(уes/no): ')
#     if choice.lower().strip() != 'yes':
#         flag = False
#         print('Пока пока!')

#     В данном упражнении мы напишем программу, выполняющую симуляцию игры в лото с одной картой. Начните с генерирования списка из всех возможных номеров для выпадения (от B1 до O75). После этого перемешайте номера в хаотичном порядке, воспользовавшись функцией shuffle из модуля random. Вытаскивайте по одному номеру из списка и зачеркивайте номера, пока карточка не окажется выигравшей. Проведите 1000 симуляций и выведите на экран минимальное, максимальное и среднее количество извлечений номеров, требующееся для выигрыша

from random import shuffle

min_draws_to_win = 10000
max_draws_to_win = 0
total_draws = 0

for _ in range(1000):
    bilet = [['b7', 'b54', 'b64', 'b12', 'b13'],
            ['i5', 'i6', 'i8', 'i9', 'i10'],
            ['n11', 'n12', 'n13', 'n14', 'n15'],
            ['g16', 'g6','g29', 'g41', 'g54'],
            ['o16', 'o17', 'o36', 'o41', 'o54']]
    numbers = [f'{x}{i}' for x in 'bingo' for i in range(76)]
    shuffle(numbers)

    diagonals = [[], []]
    i = 0
    i2 = -1
    for row in bilet:
        diagonals[0].append(row[i])
        diagonals[1].append(row[i2])
        i += 1
        i2 -= 1
    print(diagonals)

    draws = 0
    win = False
    while not win:
        draws += 1    
        lot = numbers.pop()
        # проверка попадания ряд и столб
        for row in bilet:
            if lot in row:
                row[row.index(lot)] = "X"
        # проверка попадания диагонали
        for diagonal in diagonals:
            if lot in diagonal:
                diagonal[diagonal.index(lot)] = "X"

        # проверка ряда
        for row in bilet:
            if len(set(row)) == 1:
                print(bilet)
                print('BINGO')
                win = True

        # проверка столбца
        for num in range(5):
            col = [row[num] for row in bilet]
            if len(set(row)) == 1:
                print(bilet)
                print('BINGO')
                win = True
        
        # проверка диагонали
        for diagonal in diagonals:
            if len(set(diagonal)) == 1:
                print(bilet)
                print('BINGO')
                win = True

        print(bilet)
        print()
    
    min_draws_to_win = min(min_draws_to_win, draws)
    max_draws_to_win = max(max_draws_to_win, draws)
    total_draws += draws

print(f'Min draws to win: {min_draws_to_win}')
print(f'Max draws to win: {max_draws_to_win}')
print(f'Avarage draws to win in 1000 games: {total_draws / 1000}')















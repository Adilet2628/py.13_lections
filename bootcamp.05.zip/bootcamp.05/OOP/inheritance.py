# принципы ООП
# 1. Наследование
# 2. Инкапсуляция
# 3. Полиморфизм

# 4. Абстракции
# 5. Ассоциация

# --------------------------------------
# Наследование 
# Позволяет принимать родительские методы и атрибуты дочернему классу

# Родительский класс
# Дочерний класс
# ---------------------------------

# class Animal:
#     def print_info(self):
#         print('I\'m an Animal!')

# class Lion(Animal):
#     pass

# class Dog(Animal):
#     pass

# simba = Lion()
# simba.print_info()
# print(dir(simba))
# ----------------------
# class Animal:
#     def say(self):
#         print(f'This animal name is: {self.name}: {self.golos}')

#     def eat(self):
#         print(f'{self.name} eats: {self.meal}')

# class Lion(Animal):
#     name = 'lion'
#     golos = 'roar'
#     meal = 'meat'

# class Dog(Animal):
#     name = 'dog'
#     golos = 'bark'
#     meal = 'home meat'

# class Koala(Animal):
#     name = 'koala'
#     golos = 'roar'
#     meal = 'efkalit'

# rex = Dog()
# simba = Lion()
# maris = Koala()

# rex.say()
# rex.eat()
# print()
# simba.say()
# simba.eat()
# print()
# maris.say()
# maris.eat()

# --------------------------------

# class Person:
#     def info(self):
#         print('I\'m a person from Bishkek!')

# class Student(Person):
#     def info(self):
#         super().info()
#         print('I\'m study in Manas University!')

# class Adult(Person):
#     def info(self):
#         super().info()
#         print('I\'m older than 18 years! I work 5 days in the week!')

# obj1 = Student()
# obj2 = Adult()

# obj1.info()
# print()
# obj2.info()

# --------------------------------------------

# class Laptop:
#     def __init__(self, brand, model, price) -> None:
#         self.brand = brand
#         self.model = model
#         self.price = price

#     def get_info(self):
#         return {'brand': self.brand, 'model': self.model, 'price': self.price}

# class Acer(Laptop):
#     def __init__(self, model, price, year, videocard):
#         super().__init__('Acer', model, price)
#         self.year = year
#         self.video = videocard
    
#     def get_info(self):
#         repr = super().get_info()
#         repr['year'] = self.year
#         repr['videocard'] = self.video
#         return repr

# class Apple(Laptop):
#     def __init__(self, model, price, cpu, display):
#         super().__init__('Macbook', model, price)
#         self.cpu = cpu
#         self.display = display
    
#     def get_info(self):
#         repr = super().get_info()
#         repr['display'] = self.display
#         repr['CPU'] = self.cpu
#         return repr
    
# acer = Acer('swift', 700, 2022, 'nvidia')
# print(acer.get_info())

# mac = Apple('Air', 1200, 'M2', 13.6)
# print(mac.get_info())

weapon_list = ['меч', 'лук', 'посох'] #?
role_list = ["Варвар","Бард", "Клерик", "Боец", "Лесничий", "Паладин", "Чернокнижник"]

class Character:
    from random import choice
    def __init__(self, name, weapon=False, role=False) -> None:
        self.power_list = { 'мудрость': 0, 'харизма': 0, 'интеллект': 0, 'сила': 0, 'ловкость': 0}
        self.name = name
        self.weapon = weapon
        self.role = role

    def give_weapon(self, weapon_ls):
        self.weapon = self.choice(weapon_ls)
        return self.weapon
    
    def give_role(self, role_ls):
        return self.choice(role_ls)
    
    def give_powers(self, power, value):
        self.power_list[power] = value

char1 = Character('Andrey')
char1.give_weapon(weapon_list)
print(char1.weapon)
char1.give_powers('сила', 99)
print(char1.power_list)



class Elf(Character):
    def __init__(self, name, weapon=False, role=False) -> None:
        super().__init__(name, weapon, role)
        self.power_list['магическая меткость'] = 0

    def hunter_mark(self):
        pass


silfietta = Elf('Silfi')
silfietta.give_powers('магическая меткость', 2)
silfietta.give_role(role_list)
silfietta.give_weapon(weapon_list)
silfietta.hunter_mark()
print()
print('elf:')
print(silfietta.power_list)


class Orc(Character):
    def __init__(self, name, weapon=False, role=False) -> None:
        super().__init__(name, weapon, role)
        self.power_list['неистовая ярость'] = 0

    def berserk(self):
        pass

grim = Orc('Grimmar')
grim.give_powers('неистовая ярость', 2)
grim.give_role(role_list)
grim.give_weapon(weapon_list)
grim.berserk()
print()
print('orc:')
print(grim.power_list)

print()
class Human(Character):
    def __init__(self, name, weapon=False, role=False) -> None:
        super().__init__(name, weapon, role)
        self.power_list['осознание скучности расы'] = 20
    def capitalism(self):
        pass


sanya = Human('Sanya')
sanya.give_powers('осознание скучности расы', 2)
sanya.give_role(role_list)
sanya.give_weapon(weapon_list)
sanya.capitalism()
print(sanya.power_list)



























# # dict() - словарь -> упорядоченная коллекция элементов(pyhton 3.7 -> ordered). Каждый элменет внутри словаря хранится в виде пары --> {ключ: значение}

# # ассоциативный массив, hash table, object(js) == dictionary(python)

# # thisdict = {
# #     'brand': 'Ford',
# #     'model': 'Mustang', 
# #     'year': 1967,
# # }

# # print(thisdict, type(thisdict))
# # print(thisdict['brand'], thisdict['model'])
# # print(thisdict['year'])

# # thisdict['motor'] = 'B12 Turbo'
# # print(thisdict['motor'])
# # thisdict['color'] = 'yellow'
# # print(thisdict)
# # -----------------

# # print(dir(dict))

# # items, keys, values

# # user_info = {
# #     'first_name': 'John',
# #     'last_name': 'Snow',
# #     'age': 24,
# #     'email': 'johnsnow@gmail.com',
# #     'role': 'admin',
# # }

# # kluchi = user_info.keys()
# # print(kluchi, type(kluchi))
# # ls = list(kluchi)
# # print(ls, ls[0], ls[3:])

# # ls = list(user_info.values())
# # print(ls, type(ls))
# # print(ls, ls[0], ls[3:])

# # elementy = user_info.items()
# # print(user_info)
# # print(elementy)
# #       # [('first_name', 'John'), ('last_name', 'Snow')]
# # for k, v in user_info.items():
# #     print(k, v)

# # -----------------------
# # изменение
# # dict_ = {'name': 'Jack', 'age': 17}
# # print(dict_) # {'name': 'Jack', 'age': 17}
# # dict_['name'] = 'John'
# # dict_['age'] = 24
# # print(dict_) # {'name': 'John', 'age': 24}
# # dict_.update({'name': 'Tirion', 'address': 'Westeros'})
# # print(dict_) # {'name': 'Tirion', 'age': 24, 'address': 'Westeros'}


# # ----------------------------------------
# # получение данных со словаря
# # get
# # dict_ = {1: 'pizza', 2: 'burger', 3: 'steak',}
# # # print(dict_[5], '!!!') # Error
# # print(dict_.get(5)) # None

# # setdefault - работает также как и get, но если нет такого ключа то создает новую пару из этого ключа
# # dict_ = {1: 'pizza', 2: 'burger', 3: 'steak'}
# # print(dict_)
# # print(dict_.setdefault(5, 'Manty'))
# # print(dict_)
# # -------------------------------
# # # fromkeys
# # ls = list(range(1, 100))
# # print(ls)
# # new_dict = dict.fromkeys('12345', 'value')
# # print(new_dict)
# # -------------------------------------
# # удаление элементов
# # pop, popitem

# # pop(<key>) - удаляет пару по ключу
# # dict_ = {'name': 'Jonh', 'last_name': 'Snow'}
# # print(dict_)
# # removed = dict_.pop('name')
# # print(removed)
# # print(dict_)

# # popitem - удаляет и возвращает последнию пару
# # print('\n\n')
# # dict_ = {'name': 'Jonh', 'last_name': 'Snow'}
# # print(dict_)
# # removed = dict_.popitem()
# # print(removed)
# # print(dict_)
# # -------------------------------------

# roles = {
#     1: 'Admin',
#     2: 'Customer',
#     3: 'Vendor' 
# }

# product = {
#     'id': 31,
#     'title': 'MacBook Air M1',
#     'description': 'Lorem Ipsum',
#     'price': 900
# }

# users = {
#     16: {
#         'username': 'johnsnow_12', 'password': 'bastard123', 'role': roles[1]
#     },
#     34: {
#         'username': 'tirion_small', 'password': 'short123', 'role': roles[3]
#     },
#     54: {
#         'username': 'serseya_terminator', 'password': 'terminator123', 'role': roles[2]
#     }
# }
# print(users)
# print(product)

# username = input('Vvedite svoi username: ').lower()

# user_exists = False
# for key, dict_ in users.items():
#     if username == dict_['username']:
#         id = key
#         user_exists = True

# if not user_exists:
#     raise ValueError('Username Not Found!')

# password = input('Vvedite svoi password: ').lower()

# if users[id]['password'] != password:
#     raise ValueError('Passwords did not match!')

# if users[id]['role'] == roles[1]:
#     product['description'] = input('Vvedite novoe opisaniye: ')
# else:
#     raise Exception('You do not have permissions!')

# print(product)


# ls1 = [0, 1, 2, 3, 4]
# ls2 = [0, 1, 2, 3, 4]
















